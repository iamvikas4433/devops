resource "aws_instance" "my_terra_ec2" {
  ami           = "ami-091138d0f0d41ff90"
  instance_type = "c7i-flex.large"

  root_block_device {
    volume_size           = 20
    volume_type           = "gp3"
    delete_on_termination = true
  }
  subnet_id = aws_subnet.public_subnet.id
  key_name  = aws_key_pair.task_manager_key.key_name

  vpc_security_group_ids = [aws_security_group.my_taskmanager_sg.id]

  tags = { Name = "Task-Manager-Server" }
}