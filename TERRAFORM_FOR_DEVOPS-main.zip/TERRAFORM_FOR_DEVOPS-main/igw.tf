resource "aws_internet_gateway" "my_igw" {
  vpc_id = aws_vpc.my_taskmanager_vpc.id

  tags = { Name = "My-Internet-Gateway" }
}