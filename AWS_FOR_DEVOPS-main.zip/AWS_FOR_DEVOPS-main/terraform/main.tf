resource "aws_db_instance" "mysql" {
  identifier         = "mydb"
  engine             = "mysql"
  engine_version     = "8.0"
  instance_class     = "db.t3.micro"
  allocated_storage  = 100

  username = "admin"
  password = "root123"

  skip_final_snapshot = true
}