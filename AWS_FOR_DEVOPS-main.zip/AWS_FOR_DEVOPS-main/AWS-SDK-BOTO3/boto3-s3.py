import boto3
import json

session=boto3.Session(region_name="eu-north-1")
s3_client=session.client('s3')

response=s3_client.list_buckets()
for bucket in response['Buckets']:
    name=bucket['Name']
    print(name)
