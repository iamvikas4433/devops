import boto3
import json

session=boto3.Session(region_name="eu-north-1")
iam_client=session.client('iam')

response=iam_client.list_users()
for res in response['Users']:
    print(res['UserName'])
    print(res['UserId'])
    print(res['CreateDate'])
