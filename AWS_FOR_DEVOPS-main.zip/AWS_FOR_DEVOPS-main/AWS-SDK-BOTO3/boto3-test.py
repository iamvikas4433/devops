import boto3
import json
print(boto3.__version__)

session=boto3.Session(region_name="eu-north-1")
ec2_client=session.client('ec2')

response=ec2_client.describe_instances(
    Filters=[
        {'Name':'instance-state-name','Values':['running']}
    ]
)

# print(json.dumps(response,indent=4,default=str))
print(f"List of all Running instances in region : {session.region_name}")
count_insatnces=0
for rev in response['Reservations']:
    for instance in rev['Instances']:
        count_insatnces+=1
        instance_id=instance['InstanceId']
        instance_type=instance['InstanceType']
        instance_pub_ip=instance.get('PublicIpAddress', 'No Public IP')
        state=instance['State']['Name']
        print(f"Instance Id =       {instance_id}")
        print(f"Instance Type =     {instance_type}")
        print(f"Instance Public IP = {instance_pub_ip}")
        print(f"Status = {state}")

        print("-"*40)
print(f"Total Running Instances :    {count_insatnces}")
