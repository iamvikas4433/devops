import json
import boto3
from urllib.parse import unquote_plus

sns_client=boto3.client('sns')
SNS_TOPIC_ARN="arn:aws:sns:eu-north-1:561516790720:notification-for-s3-bucket"

def lambda_handler(event,context):
    for record in event['Records']:
        event_name=record['eventName']
        bucket_name=record['s3']['bucket']['name']
        object_key=unquote_plus(record['s3']['object']['key'])
        object_size=record['s3']['object'].get('size','N/A')
        user_identity=record['userIdentity']['principalId']
        source_ip=record['requestParameters']['sourceIpAddress']

        if "ObjectCreated" in event_name:
            action_type="UPLOAD"
            emoji="🗃️"
        else:
            action_type = "DELETE"
            emoji="🪣"

        
        message=f"""{emoji} S3 BUCKET ACTIVITY ALERT{emoji}
                    ACTION : {action_type}
                    BUCKET : {bucket_name}
                    

        """

        sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Subject=f"{emoji} S3 ALERT :{action_type} on {bucket_name}",
            Message=message
        )
        return {'statusCode':200}